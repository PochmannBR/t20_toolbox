# Pochmann's Toolbox Module

v 0.1
Inseridas as armas do Ameaças de Arton e do Guia de NPCs.
	A Pistola-Punhal e a Lança-de-fogo são híbridas e devem ser puxadas para a ficha nas suas duas versões.
Inseridos Poderes do Guia de NPCs.
Inserida raças Galokk, Meio-elfo e Kallyanach.
	Kallyanach foi inserido Herança da Eletricidade. Caso o personagem possua outra herança, deve ser modificado.
Inserida Classe Samurai, com 11 poderes (não está completa).


